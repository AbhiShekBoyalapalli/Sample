import { Component, OnInit } from '@angular/core';
import { Users } from './users';
import { RestService } from './rest.service';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit
{ 
  

 

  p:number=1;
  vehicleNumber:any;
  vehicleName:any;
 

  title = 'DemoProj';
  users:Users[]=[];
  constructor( public rs: RestService)
  {

  }
  
  ngOnInit(): void
   {
    

    this.rs.getVehicleDetails().subscribe((Response: any)=>
    {this.users=Response;
    });
   
      
    }
    Search(){
      
      if(this.vehicleNumber==""){
        this.ngOnInit();
        
      }else{
        this.users=this.users.filter(res=>{
          return res.vehicleNumber.toLocaleLowerCase().match(this.vehicleNumber.toLocaleLowerCase());
        
        });
      }
      
    
    }
    deleteRow(val: number){
     {
         this.rs.deleteVehicleDetails(val).subscribe(data => {
        });
        this.rs.getVehicleDetails().subscribe((Response)=>{
          this.users=Response;
        });
      
      
      }
      
    }
    
    }
   


  


   
