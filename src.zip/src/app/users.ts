export class Users {
    id: number;
    vehicleNumber: string;
    vehicleName: string;
    maxLiftingCapacity: number;
    retireDate: Date;
    vehicleStatus: string;
    harborLocation: string;
    country: string;
    
    constructor( id: number, vehicleNumber: string,vehicleName: string,maxLiftingCapacity: number,retireDate: Date,vehicleStatus: string,harborLocation: string,country: string) 
    {
        this.id = id;
        this.vehicleNumber = vehicleNumber;
        this.vehicleName = vehicleName;
        this.maxLiftingCapacity = maxLiftingCapacity;
        this.retireDate = retireDate;
        this.vehicleStatus = vehicleStatus;
        this.harborLocation = harborLocation;
        this.country = country;
    }
}
