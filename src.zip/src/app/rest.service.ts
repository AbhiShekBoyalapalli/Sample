import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Users } from './users';
import { Observable } from 'rxjs';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RestService {
headers=new HttpHeaders().set('Content-Type','application/json').set('Accept','application/json');
httpOptions = {
  headers: this.headers
}
  constructor(private _http:HttpClient) { 
    
  }
  url:string="http://localhost:3000/VehicleDetails";

  
  getVehicleDetails(){
    return this._http.get<Users[]>(this.url);
  }
  deleteVehicleDetails(id:number):Observable<Users>{
    const url=`${this.url}/${id}`;
    return this._http.delete<Users>(url, this.httpOptions)
  }
  
}
